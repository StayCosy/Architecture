/**
 * Generic unit testing support classes.
 *
 * @see org.springframework.test.util
 */
package org.springframework.test;
