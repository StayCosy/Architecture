
Dummy web application for testing purposes.